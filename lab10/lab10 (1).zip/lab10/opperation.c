#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define EPS 1e-10


double func(const double x)
{
    double res;
    double fv = 5.0;
    __asm__ (
        "fld %1\n"        // x
        "fmul %1\n"       // x * x
        "fld %1\n"        
        "fmul %2\n"       // x * x and 5 * x
        "faddp\n"          // x * x + 5 * x
        "fsin\n"           // sin(x * x + 5 * x)
        "fstp %0"
        : "=m" (res)    
        : "m"(x),              
          "m"(fv)                    
    );
    return res;
}

void find_root(const double beg, const double end, const size_t steps, double *result)
{
    if (func(beg) * func(end) > 0) {
        printf("No root\n");
        exit(-1);
    }

    double begIt = beg;
    double endIt = end;
 
    for (size_t i = 0; i < steps; ++i) {

        if (fabs(endIt - begIt) < EPS) {
            break;
        }

        double x_m;
        double two = 2.0;
        __asm__ (

            "fld %1\n"            
            "fadd %2\n"  // begIt + endIt

            "fdiv %3\n"
           
            "fstp %0"  
            : "=m" (x_m)
            : "m" (begIt),
              "m" (endIt),
              "m" (two)
        );

        double f_x_m = func(x_m);

        if (func(begIt) * f_x_m >= 0) {
            begIt = x_m;
        } else {
            endIt  = x_m; 
        }
    }
    
    *result = (begIt + endIt) / 2;
}